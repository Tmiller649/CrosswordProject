# Sources used for backend logic taken from Harvard course CSCI E-80

## Links

https://github.com/nahueespinosa/ai50/tree/master/crossword

https://cs50.harvard.edu/extension/ai/2020/spring/projects/3/crossword/