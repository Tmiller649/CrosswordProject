[
    {
        "Answer": "RADAR",
        "Vertical": false,
        "initHorizontalCoord": 4,
        "initVerticalCoord": 0,
        "Clue": "Speed reader?",
        "complete": false
    },
    {
        "Answer": "ANAIS",
        "Vertical": true,
        "initHorizontalCoord": 5,
        "initVerticalCoord": 8,
        "Clue": "Diarist Nin",
        "complete": false
    },
    {
        "Answer": "AMEX",
        "Vertical": true,
        "initHorizontalCoord": 4,
        "initVerticalCoord": 3,
        "Clue": "Discover alternative, for short",
        "complete": false
    },
    {
        "Answer": "EDEN",
        "Vertical": false,
        "initHorizontalCoord": 2,
        "initVerticalCoord": 6,
        "Clue": "___ Prairie, suburb of Minneapolis",
        "complete": false
    },
    {
        "Answer": "BOOER",
        "Vertical": true,
        "initHorizontalCoord": 0,
        "initVerticalCoord": 4,
        "Clue": "One who's not a fan",
        "complete": false
    },
    {
        "Answer": "SKULL",
        "Vertical": true,
        "initHorizontalCoord": 5,
        "initVerticalCoord": 5,
        "Clue": "Noodle container?",
        "complete": false
    },
    {
        "Answer": "AMEN",
        "Vertical": true,
        "initHorizontalCoord": 6,
        "initVerticalCoord": 1,
        "Clue": "Enthusiastic assent",
        "complete": false
    },
    {
        "Answer": "ETTA",
        "Vertical": true,
        "initHorizontalCoord": 2,
        "initVerticalCoord": 6,
        "Clue": "James who sang \"At Last\"",
        "complete": false
    },
    {
        "Answer": "NMEX",
        "Vertical": false,
        "initHorizontalCoord": 7,
        "initVerticalCoord": 0,
        "Clue": "Where I-25 meets I-40: Abbr.",
        "complete": false
    },
    {
        "Answer": "INRE",
        "Vertical": false,
        "initHorizontalCoord": 9,
        "initVerticalCoord": 0,
        "Clue": "Concerning",
        "complete": false
    },
    {
        "Answer": "SATAN",
        "Vertical": false,
        "initHorizontalCoord": 5,
        "initVerticalCoord": 5,
        "Clue": "Lucifer",
        "complete": false
    },
    {
        "Answer": "LIBRA",
        "Vertical": true,
        "initHorizontalCoord": 0,
        "initVerticalCoord": 1,
        "Clue": "Scales up?",
        "complete": false
    },
    {
        "Answer": "AIRPOP",
        "Vertical": false,
        "initHorizontalCoord": 1,
        "initVerticalCoord": 0,
        "Clue": "Prepare, as a certain movie snack",
        "complete": false
    },
    {
        "Answer": "STEW",
        "Vertical": true,
        "initHorizontalCoord": 0,
        "initVerticalCoord": 8,
        "Clue": "Lose sleep (over)",
        "complete": false
    },
    {
        "Answer": "ELICIT",
        "Vertical": false,
        "initHorizontalCoord": 8,
        "initVerticalCoord": 4,
        "Clue": "Draw out",
        "complete": false
    },
    {
        "Answer": "LAST",
        "Vertical": false,
        "initHorizontalCoord": 0,
        "initVerticalCoord": 6,
        "Clue": "Hold up",
        "complete": false
    }
]