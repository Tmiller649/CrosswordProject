'''Creating a grid for the crosswords
Input includes: wordlist array, dimensions int since it's gonna be a square.
Output: 2d array with _ be empty spot, and * be unfillable spot.'''

# class Grid:
#     def __init__(self, wordlist, dimensions):
#         self.wordlist = wordlist
#         self.dimensions = dimensions

#     def get_grid(self):
#         return self.grid

#     def get_words_in_grid(self):
#         return self.words_in_grid

#     def generate_grid(self):
#         print("Generating a {}x{} grid with {} words.".format(self.dimensions ,len(self.wordlist)))
