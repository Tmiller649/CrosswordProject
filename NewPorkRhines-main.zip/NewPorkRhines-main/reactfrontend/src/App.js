import "./App.css";
import Crossword from "./containers/Crossword";
//import WebsiteHeader from "./containers/WebsiteHeader";

function App() {
  return (
    <>
      <div className="App">
        <Crossword />
      </div>
    </>
  );
}

export default App;
