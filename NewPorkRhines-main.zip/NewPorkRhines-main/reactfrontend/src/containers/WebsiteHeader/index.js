import "./index.scss";

function WebsiteHeader() {
  return (
    <header className="WebsiteHeader">
      <p>New Pork Rhines!</p>
    </header>
  );
}

export default WebsiteHeader;
